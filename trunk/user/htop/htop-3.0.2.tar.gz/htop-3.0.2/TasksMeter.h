#ifndef HEADER_TasksMeter
#define HEADER_TasksMeter
/*
htop - TasksMeter.h
(C) 2004-2011 Hisham H. Muhammad
Released under the GNU GPL, see the COPYING file
in the source distribution for its full text.
*/

#include "Meter.h"

extern int TasksMeter_attributes[];

extern MeterClass TasksMeter_class;

#endif
