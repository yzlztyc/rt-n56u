#ifndef HEADER_Battery
#define HEADER_Battery
/*
htop - freebsd/Battery.h
(C) 2015 Hisham H. Muhammad
Released under the GNU GPL, see the COPYING file
in the source distribution for its full text.
*/

void Battery_getData(double* level, ACPresence* isOnAC);

#endif
